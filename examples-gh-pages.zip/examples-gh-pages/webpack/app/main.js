import riot from 'riot'
import 'riot-hot-reload'
import './random.tag'

riot.mount('random', {
  title: 'Hi there!'
})

