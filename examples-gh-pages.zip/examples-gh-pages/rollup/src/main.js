import riot from 'riot'
import './app.tag'
import './md.tag'

riot.mount('app')
