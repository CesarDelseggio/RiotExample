# Riot Bug Reporter

This is a template for bug reporting.

## How to report

1. [Open this template on Plunker](http://riotjs.com/examples/plunker/?app=bug-reporter)
2. Edit & save
3. Share the url
